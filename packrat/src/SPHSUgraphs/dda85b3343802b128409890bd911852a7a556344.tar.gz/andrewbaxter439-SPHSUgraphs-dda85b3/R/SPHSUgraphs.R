#' Colour and fill palettes for Social and Public Health Sciences Unit
#'
#' Generate graph aesthetics for ggplot2
#'
#' @docType package
#' @name SPHSUgraphs
"_PACKAGE"
