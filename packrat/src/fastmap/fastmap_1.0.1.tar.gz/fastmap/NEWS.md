fastmap 1.0.1
=============

* Fixed [#13](https://github.com/r-lib/fastmap/issues/13): fastmap.cpp now explicitly includes the algorithm hedder, which is needed on some platforms to successfully compile.
