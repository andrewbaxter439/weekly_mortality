testit::test_pkg('tinytex', 'test-cran')
