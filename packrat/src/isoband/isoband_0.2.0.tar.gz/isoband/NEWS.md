isoband 0.2.0
----------------------------------------
- Added `isolines_grob()` for drawing labeled isolines via the grid graphics system.
  A companion function `isobands_grob()` is provided for convenience.
  
- Numerous minor fixes and improvements.

isoband 0.1.0
----------------------------------------
First public release.
