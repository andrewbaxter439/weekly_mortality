library("testthat")
library("plotly")

test_check("plotly")
