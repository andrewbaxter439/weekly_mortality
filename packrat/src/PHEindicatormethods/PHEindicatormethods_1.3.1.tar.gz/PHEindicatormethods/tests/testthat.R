library(testthat)
library(PHEindicatormethods)

test_check("PHEindicatormethods")
