/*=============================================================================
  Copyright (c) 1998-2008 Joel de Guzman
  Copyright (c) 2001-2008 Hartmut Kaiser

  Distributed under the Boost Software License, Version 1.0. (See accompanying
  file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
=============================================================================*/
#if !defined(BOOST_SPIRIT_CLASSIC_APR_12_2008_0949AM)
#define BOOST_SPIRIT_CLASSIC_APR_12_2008_0949AM

#include <boost/spirit/home/classic.hpp>

#endif // !defined(SPIRIT_CLASSIC_HPP)
